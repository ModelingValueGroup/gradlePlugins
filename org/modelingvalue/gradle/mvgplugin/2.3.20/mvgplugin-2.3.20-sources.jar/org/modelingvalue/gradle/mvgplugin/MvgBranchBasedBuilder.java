//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  (C) Copyright 2018-2026 Modeling Value Group B.V. (http://modelingvalue.org)                                         ~
//                                                                                                                       ~
//  Licensed under the GNU Lesser General Public License v3.0 (the 'License'). You may not use this file except in       ~
//  compliance with the License. You may obtain a copy of the License at: https://choosealicense.com/licenses/lgpl-3.0   ~
//  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on  ~
//  an 'AS IS' BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the   ~
//  specific language governing permissions and limitations under the License.                                           ~
//                                                                                                                       ~
//  Maintainers:                                                                                                         ~
//      Wim Bast, Tom Brus                                                                                               ~
//                                                                                                                       ~
//  Contributors:                                                                                                        ~
//      Ronald Krijgsheld ✝, Arjan Kok, Carel Bast                                                                       ~
// --------------------------------------------------------------------------------------------------------------------- ~
//  In Memory of Ronald Krijgsheld, 1972 - 2023                                                                          ~
//      Ronald was suddenly and unexpectedly taken from us. He was not only our long-term colleague and team member      ~
//      but also our friend. "He will live on in many of the lines of code you see below."                               ~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

package org.modelingvalue.gradle.mvgplugin;

import static org.modelingvalue.gradle.mvgplugin.Info.CI;
import static org.modelingvalue.gradle.mvgplugin.Info.LOGGER;
import static org.modelingvalue.gradle.mvgplugin.InfoGradle.isMasterBranch;
import static org.modelingvalue.gradle.mvgplugin.InfoGradle.isMvgCI_orTesting;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.gradle.api.Action;
import org.gradle.api.Project;
import org.gradle.api.artifacts.Configuration;
import org.gradle.api.artifacts.Dependency;
import org.gradle.api.artifacts.component.ComponentSelector;
import org.gradle.api.artifacts.component.ModuleComponentSelector;
import org.gradle.api.artifacts.repositories.ArtifactRepository;
import org.gradle.api.artifacts.repositories.MavenArtifactRepository;
import org.gradle.api.artifacts.repositories.PasswordCredentials;
import org.gradle.api.invocation.Gradle;
import org.gradle.api.provider.Property;
import org.gradle.api.provider.Provider;
import org.gradle.api.publish.Publication;
import org.gradle.api.publish.PublishingExtension;
import org.gradle.api.publish.maven.MavenPublication;
import org.gradle.api.services.BuildService;
import org.gradle.api.services.BuildServiceParameters;
import org.gradle.authentication.Authentication;
import org.gradle.build.event.BuildEventsListenerRegistry;
import org.gradle.tooling.events.FinishEvent;
import org.gradle.tooling.events.OperationCompletionListener;
import org.gradle.tooling.events.task.TaskFailureResult;
import org.gradle.tooling.events.task.TaskFinishEvent;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class MvgBranchBasedBuilder {
    public static final String BRANCH_INDICATOR           = "-BRANCHED";
    public static final String SNAPSHOT_VERSION_POST      = "-SNAPSHOT";
    public static final String SNAPSHOTS_GROUP_PRE        = "snapshots.";
    public static final String BRANCH_REASON              = "using Branch Based Building";
    public static final int    MAX_BRANCHNAME_PART_LENGTH = 16;

    private final Gradle                       gradle;
    private final Map<String, String>          bbbPublishingIdCache = new ConcurrentHashMap<>();
    private final Map<String, String>          bbbDependencyIdCache = new ConcurrentHashMap<>();
    private final Provider<BuildFinishService> buildFinishServiceProvider;
    private final boolean                      isCI;

    public abstract static class BuildFinishService implements BuildService<BuildFinishService.Params>, OperationCompletionListener, AutoCloseable {
        public interface Params extends BuildServiceParameters {
            Property<String> getBuildDirPath();
        }

        private final    Set<String> dependenciesToSave = ConcurrentHashMap.newKeySet();
        private final    Set<String> publications       = ConcurrentHashMap.newKeySet();
        private volatile boolean     buildFailed;

        public void addDependencyToSave(String dep) {
            dependenciesToSave.add(dep);
        }

        public void addPublication(String pub) {
            publications.add(pub);
        }

        @Override
        public void onFinish(FinishEvent event) {
            if (event instanceof TaskFinishEvent taskFinishEvent && taskFinishEvent.getResult() instanceof TaskFailureResult) {
                buildFailed = true;
            }
        }

        @Override
        public void close() {
            if (buildFailed) {
                LOGGER.info("+ mvg-bbb: skipping dependency repo update because the build failed");
                return;
            }
            DependenciesRepoManager dependencyRepoManager = new DependenciesRepoManager(Path.of(getParameters().getBuildDirPath().get()));
            dependencyRepoManager.saveDependencies(dependenciesToSave);
            dependencyRepoManager.trigger(publications);
        }
    }

    public MvgBranchBasedBuilder(Gradle gradle, BuildEventsListenerRegistry eventsListenerRegistry) {
        this.gradle = gradle;

        isCI = isMvgCI_orTesting();
        LOGGER.info("+ mvg-bbb: creating MvgBranchBasedBuilder (CI={} TEST|CI={} master={})", CI, isCI, isMasterBranch());
        TRACE.report(gradle);

        buildFinishServiceProvider = gradle.getSharedServices().registerIfAbsent(
                "mvgBuildFinish",
                BuildFinishService.class,
                spec -> spec.getParameters().getBuildDirPath().set(
                        gradle.getRootProject().getLayout().getBuildDirectory().get().getAsFile().toPath().toString()
                )
        );

        eventsListenerRegistry.onTaskCompletion(buildFinishServiceProvider);

        adjustAllDependencies();
        adjustAllPublications();
    }

    private void adjustAllDependencies() {
        gradle.allprojects(p -> p.getConfigurations().configureEach(conf -> adjustDependencies(p, conf)));
    }

    private void adjustDependencies(Project project, Configuration conf) {
        String projectName = String.format("%-30s", project.getName());
        String confName    = String.format("%-30s", conf.getName());
        conf.resolutionStrategy(strategy ->
                strategy.dependencySubstitution(depSubs ->
                        depSubs.all(depSub -> {
                                    ComponentSelector selector = depSub.getRequested();
                                    if (!(selector instanceof ModuleComponentSelector moduleComponent)) {
                                        LOGGER.info("+ mvg-bbb: {} {} can not handle unknown dependency class: {}", projectName, confName, selector.getClass());
                                    } else {
                                        if (!moduleComponent.getVersion().endsWith(BRANCH_INDICATOR)) {
                                            LOGGER.info("+ mvg-bbb: {} {} {} no BRANCH dependency: {}", Util.TEST_MARKER_REPLACE_NOT_DONE, projectName, confName, selector);
                                        } else {
                                            String       rawGroup      = moduleComponent.getGroup();
                                            String       rawArtifact   = moduleComponent.getModule();
                                            String       rawVersion    = moduleComponent.getVersion().replaceAll(Pattern.quote(BRANCH_INDICATOR) + "$", "");
                                            List<String> branchesTpTry = getBranchesTpTry();
                                            for (String branch : branchesTpTry) {
                                                String newGAV = makeBbbGAV(branch, rawGroup, rawArtifact, rawVersion);

                                                if (!branch.equals("master") && !isInAnyMavenRepo(project, newGAV)) {
                                                    LOGGER.info("+ mvg-bbb: {} {} {} BRANCH dependency not found: {} => {} (skipping this branch replacement)", Util.TEST_MARKER_REPLACE_DONE, projectName, confName, selector, newGAV);
                                                } else {
                                                    depSub.useTarget(newGAV, BRANCH_REASON);
                                                    buildFinishServiceProvider.get().addDependencyToSave(rawGroup + "." + rawArtifact);

                                                    LOGGER.info("+ mvg-bbb: {} {} {} BRANCH dependency, replaced: {} => {}", Util.TEST_MARKER_REPLACE_DONE, projectName, confName, selector, newGAV);
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                        )
                )
        );
    }

    private static @NonNull List<String> getBranchesTpTry() {
        if (InfoGradle.isMasterBranch()) {
            return List.of(InfoGradle.getBranch());
        } else if (InfoGradle.isDevelopBranch()) {
            return List.of(InfoGradle.getBranch(), "master");
        } else {
            return List.of(InfoGradle.getBranch(), "develop", "master");
        }
    }

    private boolean isInAnyMavenRepo(Project project, String gav) {
        try {
            Dependency    dependency    = project.getDependencies().create(gav);
            Configuration configuration = project.getConfigurations().detachedConfiguration(dependency);
            adjustDependencies(project, configuration);
            Set<File> resolved = configuration.resolve();
            return !resolved.isEmpty();
        } catch (Throwable e) {
            return false;
        }
    }

    private void adjustAllPublications() {
        // TODO disable all publicatons when: github.actor == "dependabot[bot]"
        gradle.afterProject(p -> {
            LOGGER.info("+ mvg-bbb: running adjustPublications on project {}", p.getName());
            PublishingExtension publishing = (PublishingExtension) p.getExtensions().findByName("publishing");
            if (publishing != null) {
                if (!publishing.getRepositories().isEmpty()) {
                    LOGGER.warn("+ mvg-bbb: The repository set for project {} is not empty; bbb will not set the proper publish repo (local-maven or github-mvg-packages). Make it empty to activate bbb publishing.", p.getName());
                }
                // only publish as-is if (master on CI), otherwise adjust the publications into snapshot
                if (!(isMasterBranch() && isCI)) {
                    makePublicationsBbb(publishing);
                }
                if (isCI) {
                    publishToGitHub(publishing);
                } else {
                    publishToMavenLocal(publishing);
                }
            }
        });
    }

    private void makePublicationsBbb(PublishingExtension publishing) {
        publishing.getPublications().configureEach(pub -> {
            if (pub instanceof MavenPublication mpub) {
                String oldGroup    = mpub.getGroupId();
                String oldArtifact = mpub.getArtifactId();
                String oldVersion  = mpub.getVersion();
                String oldGAV      = makeGAV(oldGroup, oldArtifact, oldVersion);

                String branch      = InfoGradle.getBranch();
                String newGroup    = makeBbbGroup(oldGroup, branch);
                String newArtifact = makeBbbArtifact(oldArtifact, branch);
                String newVersion  = makeBbbVersion(oldVersion, branch, true);
                String newGAV      = makeGAV(newGroup, newArtifact, newVersion);

                if (!oldGAV.equals(newGAV)) {
                    LOGGER.info("+ mvg-bbb: changed publication {}: '{}' => '{}'", mpub.getName(), oldGAV, newGAV);

                    mpub.setGroupId(newGroup);
                    mpub.setArtifactId(newArtifact);
                    mpub.setVersion(newVersion);

                    TRACE.report(publishing);

                    buildFinishServiceProvider.get().addPublication(oldGroup + "." + oldArtifact);
                }
            }
        });
    }

    private void publishToGitHub(PublishingExtension publishing) {
        if (publishing.getRepositories().isEmpty() && !publishing.getPublications().isEmpty()) {
            LOGGER.info("+ mvg-bbb: adding github publishing repo: {}", isMasterBranch() ? "master" : "snapshots");
            Action<MavenArtifactRepository> maker = InfoGradle.getGithubMavenRepoMaker(isMasterBranch());
            publishing.getRepositories().maven(maker);
            TRACE.report(publishing);
        }
    }

    private void publishToMavenLocal(PublishingExtension publishing) {
        if (publishing.getRepositories().isEmpty() && !publishing.getPublications().isEmpty()) {
            LOGGER.info("+ mvg-bbb: adding mavenLocal publishing repo...");
            publishing.getRepositories().mavenLocal();
            TRACE.report(publishing);
        }
    }

    private String makeBbbGAV(String branch, String g, String a, String v) {
        return makeGAV(makeBbbGroup(g, branch), makeBbbArtifact(a, branch), makeBbbVersion(v, branch, false));
    }

    private String makeGAV(String g, String a, String v) {
        return String.format("%s:%s:%s", g, a, v);
    }

    private String makeBbbGroup(String g, String branch) {
        return (isCI && isMasterBranch(branch)) || g.isEmpty() || g.startsWith(SNAPSHOTS_GROUP_PRE) ? g : SNAPSHOTS_GROUP_PRE + g;
    }

    private String makeBbbArtifact(String a, @SuppressWarnings("unused") String branch) {
        return a;
    }

    private String makeBbbVersion(String v, String branch, boolean forPublication) {
        if ((isCI && isMasterBranch(branch)) || v.isEmpty() || v.endsWith(SNAPSHOT_VERSION_POST)) {
            return v;
        } else {
            return (forPublication ? bbbPublishingIdCache : bbbDependencyIdCache).computeIfAbsent(branch, b -> {
                int    hash      = b.hashCode();
                String sanatized = b.replaceFirst("@.*", "").replaceAll("\\W", "_");
                String part      = sanatized.substring(0, Math.min(sanatized.length(), MAX_BRANCHNAME_PART_LENGTH));
                if (forPublication) {
                    return String.format("%s-%08x-%s%s", part, hash, Info.NOW_STAMP, SNAPSHOT_VERSION_POST);
                } else {
                    return String.format("%s-%08x+", part, hash);
                }
            });
        }
    }

    /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @SuppressWarnings("LoggingSimilarMessage")
    private static class TRACE {
        private static void report(Gradle gradle) {
            if (LOGGER.isDebugEnabled()) {
                gradle.allprojects(p -> {
                    PublishingExtension publishing = (PublishingExtension) p.getExtensions().findByName("publishing");
                    LOGGER.debug("++ mvg-bbb: ---------------------------[ proj={}", p.getName());
                    if (publishing == null) {
                        LOGGER.debug("++ mvg-bbb:     bbb publishing==null");
                    } else {
                        publishing.getPublications().forEach(x -> LOGGER.debug("++ mvg-bbb:     bbb PUBL {}: {}", x.getName(), describe(x)));
                        publishing.getRepositories().forEach(x -> LOGGER.debug("++ mvg-bbb:     bbb REPO {}: {}", x.getName(), describe(x)));
                    }
                    LOGGER.debug("++ mvg-bbb: ---------------------------] proj={}", p.getName());
                });
            }
        }

        private static void report(PublishingExtension publishing) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("++ mvg-bbb: ---------------------------[");
                if (publishing == null) {
                    LOGGER.debug("++ mvg-bbb:     bbb publishing==null");
                } else {
                    publishing.getPublications().forEach(x -> LOGGER.debug("++ mvg-bbb:     bbb PUBL {}: {}", x.getName(), describe(x)));
                    publishing.getRepositories().forEach(x -> LOGGER.debug("++ mvg-bbb:     bbb REPO {}: {}", x.getName(), describe(x)));
                }
                LOGGER.debug("++ mvg-bbb: ---------------------------]");
            }
        }

        private static String describe(Publication x) {
            if (x instanceof MavenPublication xx) {
                return xx.getGroupId() + ":" + xx.getArtifactId() + ":" + xx.getVersion();
            } else {
                return otherClass("publication", x);
            }
        }

        private static String describe(ArtifactRepository x) {
            if (x instanceof MavenArtifactRepository) {
                return describe((MavenArtifactRepository) x);
            } else {
                return otherClass("artifactRepo", x);
            }
        }

        private static String describe(MavenArtifactRepository mar) {
            if (mar == null) {
                return "<null>";
            } else {
                String credeantials = describe(mar.getCredentials());
                String authentications = mar.getAuthentication().getAsMap().entrySet().stream().map(e -> {
                    Authentication au = e.getValue();
                    return e.getKey() + ":" + au.getClass().getSimpleName();
                }).collect(Collectors.joining(", ", "Authentications[", "]"));
                return "repo url=" + mar.getUrl() + " - " + credeantials + " - " + authentications;
            }
        }

        @NotNull
        private static String describe(PasswordCredentials pwcr) {
            return pwcr.getUsername() + ":" + Util.hide(pwcr.getPassword());
        }

        private static String otherClass(String name, Object o) {
            return name + "???" + (o == null ? "<null>" : o.getClass());
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
